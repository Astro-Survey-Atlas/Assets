# GAIA public coverage

This Resource Package v3 contains reviewed gaia coverage layers from the Assets layer registry. The authoritative files are ICRS/NESTED FITS MOCs. The footprint JSON is an order-4 display projection and must not be treated as a finer measurement.

Use the official release links for scientific files and queries. Assets publishes discovery geometry and verification metadata; it does not proxy the survey archive.
