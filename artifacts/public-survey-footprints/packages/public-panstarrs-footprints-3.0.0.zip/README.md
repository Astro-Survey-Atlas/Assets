# Pan-STARRS1

Pan-STARRS1 DR1 彩色及 grizy HiPS 图像覆盖。
