"""Resource Package v3 deterministic builder and hostile-ZIP validator."""

from __future__ import annotations

import hashlib
import json
import os
import re
import stat
import tempfile
import zipfile
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from typing import Any, Mapping

from .contract import COVERAGE_ROLES, DATA_ORIGINS, SOURCE_TIERS
from .core import canonical_json, project_cells, validate_moc_fits

PACKAGE_VERSION = "3.0.0"
PACKAGE_VERSION_PATTERN = re.compile(r"^3\.\d+\.\d+$")
REQUIRED_FILES = frozenset(("resource-package.json", "footprints/survey-footprints.json", "provenance.json", "README.md"))
REQUIRED_SUPPORT_FILES = frozenset(("footprints/survey-footprints.json", "provenance.json", "README.md"))
OPTIONAL_HEALPIX_FILES = frozenset(("healpix/order4.json", "healpix/order8.json"))
HEALPIX_PRECISIONS = frozenset(("exact", "estimated", "unknown"))
HEALPIX_COMPLETENESS = frozenset(("complete", "incomplete", "unknown"))
MAX_ENTRY_BYTES = 512 * 1024 * 1024
MAX_PACKAGE_BYTES = 2 * 1024 * 1024 * 1024
MAX_ENTRIES = 10_000


class PackageValidationError(ValueError):
    """Raised when a resource package is malformed or unsafe."""


@dataclass(frozen=True)
class ValidatedPackage:
    manifest: Mapping[str, Any]
    archive_sha256: str
    entries: tuple[str, ...]


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _safe_name(name: str) -> str:
    if not name or "\x00" in name or "\\" in name:
        raise PackageValidationError(f"Unsafe ZIP entry: {name!r}")
    path = PurePosixPath(name)
    if path.is_absolute() or any(part in {"", ".", ".."} for part in path.parts):
        raise PackageValidationError(f"Unsafe ZIP entry: {name!r}")
    normalized = path.as_posix()
    allowed = (
        normalized in REQUIRED_FILES
        or normalized in OPTIONAL_HEALPIX_FILES
        or (normalized.startswith("mocs/") and normalized.endswith(".moc.fits"))
    )
    if not allowed:
        raise PackageValidationError(f"Unexpected v3 package entry: {normalized}")
    return normalized


def _validate_layer(layer: Mapping[str, Any], names: set[str]) -> None:
    required = ("layerId", "surveyId", "coverageRole", "dataOrigin", "sourceTier", "modality", "releaseId", "path", "sizeBytes", "sha256")
    missing = [key for key in required if key not in layer]
    if missing:
        raise PackageValidationError(f"Layer is missing fields: {', '.join(missing)}")
    if "evidenceRole" in layer:
        raise PackageValidationError("evidenceRole is removed; use coverageRole")
    layer_id = layer["layerId"]
    if not isinstance(layer_id, str) or re.fullmatch(r"[a-z0-9][a-z0-9-]*", layer_id) is None:
        raise PackageValidationError(f"Invalid layerId: {layer_id}")
    expected_path = f"mocs/{layer_id}.moc.fits"
    if layer["path"] != expected_path or expected_path not in names:
        raise PackageValidationError(f"Layer path must be {expected_path}")
    if layer["coverageRole"] not in COVERAGE_ROLES:
        raise PackageValidationError(f"Invalid coverageRole for {layer_id}")
    if layer["dataOrigin"] not in DATA_ORIGINS:
        raise PackageValidationError(f"Invalid dataOrigin for {layer_id}")
    if layer["sourceTier"] not in SOURCE_TIERS:
        raise PackageValidationError(f"Invalid sourceTier for {layer_id}")
    if "coordinateFrame" in layer and layer["coordinateFrame"] != "ICRS":
        raise PackageValidationError(f"Only ICRS is supported for {layer_id}")
    if "ordering" in layer and layer["ordering"] != "NESTED":
        raise PackageValidationError(f"Only NESTED ordering is supported for {layer_id}")
    for key in ("surveyId", "modality", "releaseId"):
        if not isinstance(layer[key], str) or not layer[key].strip():
            raise PackageValidationError(f"Invalid {key} for {layer_id}")
    for key in ("sourceId", "productId", "product", "coverageRevision"):
        if key in layer and (not isinstance(layer[key], str) or not layer[key].strip()):
            raise PackageValidationError(f"Invalid {key} for {layer_id}")
    if "availableOrders" in layer:
        orders = layer["availableOrders"]
        if (
            not isinstance(orders, list)
            or any(type(order) is not int or not 0 <= order <= 29 for order in orders)
            or len(set(orders)) != len(orders)
        ):
            raise PackageValidationError(f"Invalid availableOrders for {layer_id}")
    for key in ("overviewOrder", "maxOrder"):
        if key in layer and (type(layer[key]) is not int or not 0 <= layer[key] <= 29):
            raise PackageValidationError(f"Invalid {key} for {layer_id}")
    if "geometryPrecision" in layer and (not isinstance(layer["geometryPrecision"], str) or layer["geometryPrecision"] not in HEALPIX_PRECISIONS):
        raise PackageValidationError(f"Invalid geometryPrecision for {layer_id}")
    if "completeness" in layer and (not isinstance(layer["completeness"], str) or layer["completeness"] not in HEALPIX_COMPLETENESS):
        raise PackageValidationError(f"Invalid completeness for {layer_id}")
    if "precisionNote" in layer and (not isinstance(layer["precisionNote"], str) or not layer["precisionNote"].strip()):
        raise PackageValidationError(f"Invalid precisionNote for {layer_id}")
    if "indexRevision" in layer and layer["indexRevision"] is not None and (not isinstance(layer["indexRevision"], str) or not layer["indexRevision"].strip()):
        raise PackageValidationError(f"Invalid indexRevision for {layer_id}")
    for key in ("accessAvailability", "mocEncoding"):
        if key in layer and (not isinstance(layer[key], str) or not layer[key].strip()):
            raise PackageValidationError(f"Invalid {key} for {layer_id}")
    if not isinstance(layer["sizeBytes"], int) or layer["sizeBytes"] < 1:
        raise PackageValidationError(f"Invalid sizeBytes for {layer_id}")
    if not isinstance(layer["sha256"], str) or re.fullmatch(r"[a-f0-9]{64}", layer["sha256"]) is None:
        raise PackageValidationError(f"Invalid SHA-256 for {layer_id}")


def _validate_healpix_cells(value: Any, order: int, label: str) -> list[int]:
    if not isinstance(value, list):
        raise PackageValidationError(f"{label} cells must be an array")
    limit = 12 * (4**order)
    previous = -1
    for cell in value:
        if type(cell) is not int or cell <= previous or cell >= limit:
            raise PackageValidationError(f"{label} cells must be strictly increasing in-range integers")
        previous = cell
    return value


def _unique_json_object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise PackageValidationError(f"Duplicate JSON field: {key}")
        result[key] = value
    return result


def _validate_healpix_sidecar(data: bytes, manifest: Mapping[str, Any], order: int) -> None:
    try:
        sidecar = json.loads(data, object_pairs_hook=_unique_json_object)
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        raise PackageValidationError(f"Invalid order-{order} HEALPix sidecar JSON") from error
    required_keys = {
        "schemaVersion", "surveyId", "packageId", "packageVersion", "revision",
        "coordinateFrame", "ordering", "order", "layers", "surveyUnion",
    }
    if not isinstance(sidecar, Mapping) or set(sidecar) != required_keys:
        raise PackageValidationError(f"Invalid order-{order} HEALPix sidecar shape")
    if (
        type(sidecar["schemaVersion"]) is not int
        or sidecar["schemaVersion"] != 1
        or not isinstance(sidecar["surveyId"], str)
        or not sidecar["surveyId"].strip()
        or sidecar["surveyId"] != manifest.get("surveyId")
        or sidecar["packageId"] != manifest.get("id")
        or sidecar["packageVersion"] != manifest.get("version")
        or not isinstance(sidecar["revision"], str)
        or not sidecar["revision"].strip()
        or len(sidecar["revision"]) > 160
        or sidecar["coordinateFrame"] != "ICRS"
        or sidecar["ordering"] != "NESTED"
        or type(sidecar["order"]) is not int
        or sidecar["order"] != order
    ):
        raise PackageValidationError(f"Invalid order-{order} HEALPix sidecar identity")

    manifest_layers = manifest.get("layers")
    if not isinstance(manifest_layers, list):
        raise PackageValidationError("Resource Package v3 requires layer records")
    manifest_by_id = {layer["layerId"]: layer for layer in manifest_layers if isinstance(layer, Mapping) and isinstance(layer.get("layerId"), str)}
    sidecar_layers = sidecar["layers"]
    union = sidecar["surveyUnion"]
    if not isinstance(sidecar_layers, list) or not isinstance(union, Mapping) or set(union) != {"cells", "precision", "completeness", "omittedLayers"}:
        raise PackageValidationError(f"Invalid order-{order} HEALPix sidecar layers or survey union")
    omitted = union["omittedLayers"]
    if not isinstance(omitted, list):
        raise PackageValidationError(f"Invalid omittedLayers for order-{order} HEALPix sidecar")
    omitted_ids: set[str] = set()
    for index, omitted_layer in enumerate(omitted):
        if not isinstance(omitted_layer, Mapping) or set(omitted_layer) != {"layerId", "reason"}:
            raise PackageValidationError(f"Invalid omitted layer record {index} for order-{order} sidecar")
        layer_id = omitted_layer["layerId"]
        reason = omitted_layer["reason"]
        if not isinstance(layer_id, str) or not layer_id.strip() or not isinstance(reason, str) or not reason.strip() or len(reason) > 1000 or layer_id in omitted_ids:
            raise PackageValidationError(f"Invalid omitted layer record {index} for order-{order} sidecar")
        omitted_ids.add(layer_id)
    if (
        not isinstance(union["precision"], str)
        or union["precision"] not in HEALPIX_PRECISIONS
        or not isinstance(union["completeness"], str)
        or union["completeness"] not in HEALPIX_COMPLETENESS
    ):
        raise PackageValidationError(f"Invalid surveyUnion precision or completeness for order-{order}")
    union_cells = _validate_healpix_cells(union["cells"], order, f"order-{order} surveyUnion")

    seen: set[str] = set()
    listed_cells: set[int] = set()
    for sidecar_layer in sidecar_layers:
        if not isinstance(sidecar_layer, Mapping):
            raise PackageValidationError(f"Invalid layer record in order-{order} HEALPix sidecar")
        layer_id = sidecar_layer.get("layerId")
        if not isinstance(layer_id, str):
            raise PackageValidationError(f"Invalid layer identity in order-{order} HEALPix sidecar")
        expected_manifest = manifest_by_id.get(layer_id)
        if expected_manifest is None or layer_id in seen:
            raise PackageValidationError(f"Unknown or duplicate layer in order-{order} HEALPix sidecar: {layer_id}")
        identity_keys = ("layerId", "surveyId", "releaseId", "productId", "product")
        expected_keys = set(identity_keys) | {"cells", "precision", "completeness"}
        if "sourceId" in expected_manifest:
            expected_keys.add("sourceId")
        if set(sidecar_layer) != expected_keys:
            raise PackageValidationError(f"Invalid sidecar layer shape for {layer_id}")
        for key in identity_keys:
            if (
                key not in expected_manifest
                or not isinstance(sidecar_layer[key], str)
                or not sidecar_layer[key].strip()
                or sidecar_layer[key] != expected_manifest[key]
            ):
                raise PackageValidationError(f"Sidecar identity mismatch for {layer_id}: {key}")
        if "sourceId" in expected_manifest and sidecar_layer["sourceId"] != expected_manifest["sourceId"]:
            raise PackageValidationError(f"Sidecar identity mismatch for {layer_id}: sourceId")
        if type(expected_manifest.get("maxOrder")) is not int or expected_manifest["maxOrder"] < order:
            raise PackageValidationError(f"Layer maxOrder is below sidecar order for {layer_id}")
        if (
            not isinstance(sidecar_layer["precision"], str)
            or sidecar_layer["precision"] not in HEALPIX_PRECISIONS
            or not isinstance(sidecar_layer["completeness"], str)
            or sidecar_layer["completeness"] not in HEALPIX_COMPLETENESS
        ):
            raise PackageValidationError(f"Invalid precision or completeness for sidecar layer {layer_id}")
        cells = _validate_healpix_cells(sidecar_layer["cells"], order, f"order-{order} layer {layer_id}")
        seen.add(layer_id)
        listed_cells.update(cells)

    if seen & omitted_ids or seen | omitted_ids != set(manifest_by_id):
        raise PackageValidationError(f"Every manifest layer must be listed or omitted exactly once in order-{order} sidecar")
    if listed_cells != set(union_cells):
        raise PackageValidationError(f"order-{order} surveyUnion cells must equal the listed layer union")
    if (omitted_ids or any(layer["completeness"] != "complete" for layer in sidecar_layers)) and union["completeness"] == "complete":
        raise PackageValidationError(f"order-{order} surveyUnion cannot be complete when layers are omitted or incomplete")


def _build_healpix_sidecars(
    package_id: str,
    package_version: str,
    survey_id: str,
    layers: list[dict[str, Any]],
    native_cells_by_layer: Mapping[str, tuple[tuple[int, int], ...]],
) -> dict[str, bytes]:
    if not isinstance(survey_id, str) or not survey_id.strip():
        raise PackageValidationError("HEALPix sidecars require a package surveyId")
    revision = f"{package_id}@{package_version}"
    if len(revision) > 160:
        raise PackageValidationError("HEALPix sidecar revision exceeds 160 characters")

    result: dict[str, bytes] = {}
    for order in (4, 8):
        sidecar_layers: list[dict[str, Any]] = []
        omitted_layers: list[dict[str, str]] = []
        union_cells: set[int] = set()
        precisions: list[str] = []
        completenesses: list[str] = []
        for layer in sorted(layers, key=lambda item: item["layerId"]):
            layer_id = layer["layerId"]
            native_max_order = layer["maxOrder"]
            if native_max_order < order:
                omitted_layers.append({
                    "layerId": layer_id,
                    "reason": f"Native MOC maximum is O{native_max_order}; no O{order} list is produced for this layer.",
                })
                continue
            for key in ("surveyId", "releaseId", "productId", "product"):
                if not isinstance(layer.get(key), str) or not layer[key].strip():
                    raise PackageValidationError(f"HEALPix sidecar layer {layer_id} requires {key}")
            precision = layer.get("geometryPrecision")
            if not isinstance(precision, str) or precision not in HEALPIX_PRECISIONS:
                precision = "unknown"
            completeness = layer.get("completeness")
            if not isinstance(completeness, str) or completeness not in HEALPIX_COMPLETENESS:
                completeness = "unknown"
            cells = project_cells(native_cells_by_layer[layer_id], order)
            identity = {key: layer[key] for key in ("layerId", "surveyId", "releaseId", "productId", "product")}
            if "sourceId" in layer:
                identity["sourceId"] = layer["sourceId"]
            sidecar_layers.append({
                **identity,
                "cells": list(cells),
                "precision": precision,
                "completeness": completeness,
            })
            union_cells.update(cells)
            precisions.append(precision)
            completenesses.append(completeness)

        if not precisions or "unknown" in precisions:
            union_precision = "unknown"
        elif "estimated" in precisions:
            union_precision = "estimated"
        else:
            union_precision = "exact"
        if omitted_layers or "incomplete" in completenesses:
            union_completeness = "incomplete"
        elif completenesses and all(value == "complete" for value in completenesses):
            union_completeness = "complete"
        else:
            union_completeness = "unknown"
        document = {
            "schemaVersion": 1,
            "surveyId": survey_id,
            "packageId": package_id,
            "packageVersion": package_version,
            "revision": revision,
            "coordinateFrame": "ICRS",
            "ordering": "NESTED",
            "order": order,
            "layers": sidecar_layers,
            "surveyUnion": {
                "cells": sorted(union_cells),
                "precision": union_precision,
                "completeness": union_completeness,
                "omittedLayers": omitted_layers,
            },
        }
        result[f"healpix/order{order}.json"] = canonical_json(document) + b"\n"
    return result


def validate_resource_package(archive: str | Path, *, require_public_catalog: Mapping[str, Any] | None = None) -> ValidatedPackage:
    """Validate v3 structure, paths, links, limits, MOCs and all hashes.

    Passing ``require_public_catalog`` enables the public trust gate: the archive
    hash and package ID/version must be present in the Assets-owned catalog.
    """

    archive_path = Path(archive)
    if archive_path.stat().st_size > MAX_PACKAGE_BYTES:
        raise PackageValidationError("ZIP exceeds the archive size limit")
    archive_sha256 = _sha256(archive_path)
    with zipfile.ZipFile(archive_path) as source:
        infos = source.infolist()
        if len(infos) > MAX_ENTRIES:
            raise PackageValidationError("ZIP contains too many entries")
        names: list[str] = []
        total = 0
        for info in infos:
            name = _safe_name(info.filename)
            if name in names:
                raise PackageValidationError(f"Duplicate ZIP entry: {name}")
            names.append(name)
            mode = info.external_attr >> 16
            if stat.S_ISLNK(mode):
                raise PackageValidationError(f"Symbolic links are forbidden: {name}")
            if info.flag_bits & 0x1:
                raise PackageValidationError(f"Encrypted entries are forbidden: {name}")
            if info.is_dir():
                raise PackageValidationError(f"Directory entries are not part of v3: {name}")
            if info.file_size < 1 or info.file_size > MAX_ENTRY_BYTES:
                raise PackageValidationError(f"Invalid uncompressed size for {name}")
            total += info.file_size
            if total > MAX_PACKAGE_BYTES:
                raise PackageValidationError("ZIP exceeds the uncompressed size limit")
        name_set = set(names)
        missing = REQUIRED_FILES - name_set
        if missing:
            raise PackageValidationError(f"Missing v3 entries: {', '.join(sorted(missing))}")
        manifest = json.loads(source.read("resource-package.json"))
        if manifest.get("schemaVersion") != 3 or not isinstance(manifest.get("version"), str) or not PACKAGE_VERSION_PATTERN.match(manifest["version"]):
            raise PackageValidationError("Only Resource Package v3 (3.x.y) is accepted")
        if "evidenceRole" in manifest:
            raise PackageValidationError("evidenceRole is removed; use coverageRole")
        if "coordinateFrame" in manifest and manifest["coordinateFrame"] != "ICRS":
            raise PackageValidationError("Only ICRS is supported by Resource Package v3")
        if "ordering" in manifest and manifest["ordering"] != "NESTED":
            raise PackageValidationError("Only NESTED ordering is supported by Resource Package v3")
        package_id = manifest.get("id")
        if not isinstance(package_id, str) or re.fullmatch(r"[a-z0-9][a-z0-9-]*", package_id) is None:
            raise PackageValidationError("Resource Package v3 requires a stable package id")
        layers = manifest.get("layers")
        if not isinstance(layers, list) or not layers:
            raise PackageValidationError("Resource Package v3 requires at least one layer")
        layer_ids: set[str] = set()
        for layer in layers:
            if not isinstance(layer, Mapping):
                raise PackageValidationError("Layer records must be JSON objects")
            _validate_layer(layer, name_set)
            if layer["layerId"] in layer_ids:
                raise PackageValidationError(f"Duplicate layerId: {layer['layerId']}")
            layer_ids.add(layer["layerId"])
            info = source.getinfo(layer["path"])
            if info.file_size != layer["sizeBytes"]:
                raise PackageValidationError(f"Size mismatch: {layer['path']}")
            data = source.read(layer["path"])
            if hashlib.sha256(data).hexdigest() != layer["sha256"]:
                raise PackageValidationError(f"SHA-256 mismatch: {layer['path']}")
            with tempfile.NamedTemporaryFile(suffix=".moc.fits") as handle:
                handle.write(data)
                handle.flush()
                validate_moc_fits(handle.name)
        moc_entries = {name for name in name_set if name.startswith("mocs/")}
        declared_mocs = {layer["path"] for layer in layers}
        if moc_entries != declared_mocs:
            raise PackageValidationError("Every MOC must have exactly one manifest layer")
        support = manifest.get("files")
        if not isinstance(support, list) or not 3 <= len(support) <= 5:
            raise PackageValidationError("Resource Package v3 requires supporting file hashes")
        if any(not isinstance(record, Mapping) or not isinstance(record.get("path"), str) for record in support):
            raise PackageValidationError("Invalid supporting file record")
        support_paths = [record["path"] for record in support]
        declared_support_paths = set(support_paths)
        if (
            len(declared_support_paths) != len(support)
            or not REQUIRED_SUPPORT_FILES.issubset(declared_support_paths)
            or not declared_support_paths.issubset(REQUIRED_SUPPORT_FILES | OPTIONAL_HEALPIX_FILES)
            or declared_support_paths != name_set.intersection(REQUIRED_SUPPORT_FILES | OPTIONAL_HEALPIX_FILES)
        ):
            raise PackageValidationError("Supporting file manifest is incomplete")
        for record in support:
            if (
                not isinstance(record, Mapping)
                or not isinstance(record.get("path"), str)
                or type(record.get("sizeBytes")) is not int
                or record["sizeBytes"] < 1
                or re.fullmatch(r"[a-f0-9]{64}", str(record.get("sha256", ""))) is None
            ):
                raise PackageValidationError("Invalid supporting file record")
            if record["path"] not in name_set:
                raise PackageValidationError(f"Supporting file is missing: {record['path']}")
            info = source.getinfo(record["path"])
            data = source.read(record["path"])
            if info.file_size != record["sizeBytes"] or hashlib.sha256(data).hexdigest() != record["sha256"]:
                raise PackageValidationError(f"Supporting file mismatch: {record['path']}")
            if record["path"] in OPTIONAL_HEALPIX_FILES:
                order = 4 if record["path"] == "healpix/order4.json" else 8
                _validate_healpix_sidecar(data, manifest, order)
        try:
            footprint = json.loads(source.read("footprints/survey-footprints.json"))
            provenance = json.loads(source.read("provenance.json"))
            source.read("README.md").decode("utf-8")
        except (UnicodeDecodeError, json.JSONDecodeError) as error:
            raise PackageValidationError("Supporting files must be valid JSON and UTF-8") from error
        if not isinstance(footprint, Mapping) or not isinstance(footprint.get("footprints"), list):
            raise PackageValidationError("Invalid survey footprint manifest")
        if not isinstance(provenance, Mapping) or provenance.get("schemaVersion") is None:
            raise PackageValidationError("Invalid provenance document")
        if require_public_catalog is not None:
            matches = [entry for entry in require_public_catalog.get("packages", []) if entry.get("id") == manifest.get("id") and entry.get("version") == manifest.get("version")]
            if not any(entry.get("sha256") == archive_sha256 for entry in matches):
                raise PackageValidationError("Package is not trusted by the Assets public catalog")
    return ValidatedPackage(manifest, archive_sha256, tuple(names))


def _zip_timestamp() -> tuple[int, int, int, int, int, int]:
    epoch = int(os.environ.get("SOURCE_DATE_EPOCH", "315532800"))
    # ZIP timestamps cannot predate 1980 and are stored at two-second precision.
    when = datetime.fromtimestamp(max(epoch, 315532800), tz=timezone.utc)
    return (when.year, when.month, when.day, when.hour, when.minute, when.second - (when.second % 2))


def _zip_write(archive: zipfile.ZipFile, name: str, data: bytes) -> None:
    info = zipfile.ZipInfo(name, _zip_timestamp())
    info.compress_type = zipfile.ZIP_DEFLATED
    info.create_system = 3
    info.external_attr = 0o100644 << 16
    archive.writestr(info, data, compresslevel=9)


def build_resource_package(spec: Mapping[str, Any], output: str | Path, *, base_dir: str | Path = ".") -> ValidatedPackage:
    """Build a deterministic v3 archive from local, already-reviewed inputs."""

    include_healpix_sidecars = spec.get("includeHealpixSidecars", False)
    if type(include_healpix_sidecars) is not bool:
        raise PackageValidationError("includeHealpixSidecars must be a boolean")
    version = str(spec.get("version", PACKAGE_VERSION))
    if not PACKAGE_VERSION_PATTERN.match(version):
        raise PackageValidationError("New Assets builds only produce Resource Package 3.x.y")
    package_id = spec.get("id")
    if not isinstance(package_id, str) or not package_id:
        raise PackageValidationError("Package id is required")
    base = Path(base_dir)
    footprint_source = base / str(spec.get("footprintPath", ""))
    provenance_source = base / str(spec.get("provenancePath", ""))
    readme_source = base / str(spec.get("readmePath", ""))
    for source in (footprint_source, provenance_source, readme_source):
        if not source.is_file():
            raise PackageValidationError(f"Package source is missing: {source}")
    layers: list[dict[str, Any]] = []
    moc_files: dict[str, bytes] = {}
    native_cells_by_layer: dict[str, tuple[tuple[int, int], ...]] = {}
    for raw in spec.get("layers", []):
        source = base / str(raw.get("sourcePath", ""))
        if not source.is_file():
            raise PackageValidationError(f"Layer source is missing: {source}")
        native_cells = validate_moc_fits(source)
        available_orders = sorted({order for order, _ in native_cells})
        native_max_order = max(available_orders, default=0)
        layer_id = raw.get("layerId")
        if not isinstance(layer_id, str):
            raise PackageValidationError("Layer layerId is required")
        if "maxOrder" in raw and (type(raw["maxOrder"]) is not int or raw["maxOrder"] != native_max_order):
            raise PackageValidationError(f"Layer {layer_id} maxOrder disagrees with its native MOC")
        target = f"mocs/{layer_id}.moc.fits"
        data = source.read_bytes()
        layer = {key: raw[key] for key in ("layerId", "surveyId", "coverageRole", "dataOrigin", "sourceTier", "modality", "releaseId")}
        optional_layer_metadata = (
            "sourceId", "productId", "product", "overviewOrder",
            "coverageRevision", "indexRevision", "geometryPrecision", "completeness", "precisionNote",
            "accessAvailability", "coordinateFrame", "ordering", "mocEncoding",
        )
        layer.update({key: raw[key] for key in optional_layer_metadata if key in raw})
        layer["availableOrders"] = available_orders
        layer["maxOrder"] = native_max_order
        layer.update({"path": target, "sizeBytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})
        layers.append(layer)
        moc_files[target] = data
        native_cells_by_layer[layer_id] = native_cells
    support_data = {
        "footprints/survey-footprints.json": footprint_source.read_bytes(),
        "provenance.json": provenance_source.read_bytes(),
        "README.md": readme_source.read_bytes(),
    }
    support_files = spec.get("supportFiles", [])
    if not isinstance(support_files, list):
        raise PackageValidationError("supportFiles must be a list")
    for item in support_files:
        if not isinstance(item, Mapping) or set(item) != {"path", "sourcePath"}:
            raise PackageValidationError("Each supportFiles item must declare only path and sourcePath")
        target = item["path"]
        source_value = item["sourcePath"]
        if not isinstance(target, str) or target not in OPTIONAL_HEALPIX_FILES or not isinstance(source_value, str) or not source_value:
            raise PackageValidationError(f"Unsupported optional support file: {target}")
        if target in support_data:
            raise PackageValidationError(f"Duplicate optional support file: {target}")
        source_path = base / source_value
        if not source_path.is_file():
            raise PackageValidationError(f"Package source is missing: {source_path}")
        support_data[target] = source_path.read_bytes()
    if include_healpix_sidecars:
        if any(path in support_data for path in OPTIONAL_HEALPIX_FILES):
            raise PackageValidationError("includeHealpixSidecars cannot be combined with explicit HEALPix supportFiles")
        support_data.update(_build_healpix_sidecars(
            package_id,
            version,
            spec.get("surveyId"),
            layers,
            native_cells_by_layer,
        ))
    manifest = {
        "schemaVersion": 3,
        "id": package_id,
        "version": version,
        "surveyId": spec.get("surveyId"),
        "layers": sorted(layers, key=lambda layer: layer["layerId"]),
        "files": [
            {"path": name, "sizeBytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
            for name, data in sorted(support_data.items())
        ],
    }
    output_path = Path(output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    temporary: str | None = None
    try:
        with tempfile.NamedTemporaryFile(dir=output_path.parent, prefix=f".{output_path.name}.", delete=False) as handle:
            temporary = handle.name
        with zipfile.ZipFile(temporary, "w", allowZip64=True) as archive:
            entries = {
                "resource-package.json": canonical_json(manifest) + b"\n",
                **moc_files,
                **support_data,
            }
            for name in sorted(entries):
                _zip_write(archive, name, entries[name])
        validated = validate_resource_package(temporary)
        os.replace(temporary, output_path)
        temporary = None
        return validated
    finally:
        if temporary is not None:
            Path(temporary).unlink(missing_ok=True)
